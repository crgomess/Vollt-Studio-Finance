import React, { useState, useEffect } from 'react';
import {
  AppData,
  ActiveTab,
  Transaction,
  Account,
  CreditCard,
  FinancialGoal,
  Task,
  Habit,
  NoteItem,
  TaskStatus,
} from './types';
import {
  OpenFinanceConsent,
  PortabilityRequest,
  AutomatedTransferRule,
  SecurityConfig,
} from './types/openFinance';
import { loadAppData, saveAppData, INITIAL_DATA, INITIAL_SECURITY } from './utils/storage';
import { formatDateBR } from './utils/formatters';
import { Navbar } from './components/layout/Navbar';
import { BottomNav } from './components/layout/BottomNav';
import { ToastContainer, ToastMessage } from './components/common/Toast';
import { QuickActionModal } from './components/common/QuickActionModal';
import { DataSettingsModal } from './components/settings/DataSettingsModal';
import { SupabaseModal } from './components/supabase/SupabaseModal';
import { SecuritySettingsModal } from './components/security/SecuritySettingsModal';
import { TransferReceiptModal, TransferReceiptData } from './components/finance/TransferReceiptModal';

// Modals
import { TransactionModal } from './components/finance/TransactionModal';
import { TaskModal } from './components/personal/TaskModal';
import { HabitModal } from './components/personal/HabitModal';
import { GoalModal } from './components/finance/GoalModal';
import { NoteModal } from './components/personal/NoteModal';

// Views
import { OverviewDashboard } from './components/dashboard/OverviewDashboard';
import { FinanceModule } from './components/finance/FinanceModule';
import { TaskManager } from './components/personal/TaskManager';
import { HabitsTracker } from './components/personal/HabitsTracker';
import { NotesAgenda } from './components/personal/NotesAgenda';

function calculateNextExecution(frequencia: 'diaria' | 'semanal' | 'mensal', fromDateStr: string): string {
  const d = new Date(fromDateStr);
  if (frequencia === 'diaria') {
    d.setDate(d.getDate() + 1);
  } else if (frequencia === 'semanal') {
    d.setDate(d.getDate() + 7);
  } else {
    d.setMonth(d.getMonth() + 1);
  }
  return d.toISOString().slice(0, 10);
}

export default function App() {
  const [data, setData] = useState<AppData>(() => loadAppData());
  const [activeTab, setActiveTab] = useState<ActiveTab>('overview');
  const [financeSubTab, setFinanceSubTab] = useState<
    'charts' | 'transactions' | 'accounts' | 'goals' | 'openfinance'
  >('charts');
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Dark Mode state
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  });

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  // Persist data on change
  useEffect(() => {
    saveAppData(data);
  }, [data]);

  // Toast helper
  const addToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    const id = `toast-${Date.now()}-${Math.random()}`;
    setToasts((prev) => [...prev, { id, type, message }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3500);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Modal open states
  const [isQuickActionOpen, setIsQuickActionOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isSupabaseModalOpen, setIsSupabaseModalOpen] = useState(false);
  const [isSecurityModalOpen, setIsSecurityModalOpen] = useState(false);
  const [receiptData, setReceiptData] = useState<TransferReceiptData | null>(null);

  const [isTxModalOpen, setIsTxModalOpen] = useState(false);
  const [editingTx, setEditingTx] = useState<Transaction | null>(null);

  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);

  const [isHabitModalOpen, setIsHabitModalOpen] = useState(false);
  const [editingHabit, setEditingHabit] = useState<Habit | null>(null);

  const [isGoalModalOpen, setIsGoalModalOpen] = useState(false);
  const [editingGoal, setEditingGoal] = useState<FinancialGoal | null>(null);

  const [isNoteModalOpen, setIsNoteModalOpen] = useState(false);
  const [editingNote, setEditingNote] = useState<NoteItem | null>(null);

  // Quick Action Handler
  const handleQuickActionSelect = (action: 'transaction' | 'task' | 'habit' | 'goal' | 'note') => {
    switch (action) {
      case 'transaction':
        setEditingTx(null);
        setIsTxModalOpen(true);
        break;
      case 'task':
        setEditingTask(null);
        setIsTaskModalOpen(true);
        break;
      case 'habit':
        setEditingHabit(null);
        setIsHabitModalOpen(true);
        break;
      case 'goal':
        setEditingGoal(null);
        setIsGoalModalOpen(true);
        break;
      case 'note':
        setEditingNote(null);
        setIsNoteModalOpen(true);
        break;
    }
  };

  // --- TRANSACTIONS HANDLERS ---
  const handleSaveTransaction = (txData: Omit<Transaction, 'id'>, editId?: string) => {
    if (editId) {
      setData((prev) => ({
        ...prev,
        transacoes: prev.transacoes.map((t) => (t.id === editId ? { ...txData, id: editId } : t)),
      }));
      addToast('Transação atualizada com sucesso!');
    } else {
      const newTx: Transaction = {
        ...txData,
        id: `tx-${Date.now()}`,
      };
      setData((prev) => ({
        ...prev,
        transacoes: [newTx, ...prev.transacoes],
      }));
      addToast('Nova transação adicionada!');
    }
  };

  const handleDeleteTransaction = (id: string) => {
    setData((prev) => ({
      ...prev,
      transacoes: prev.transacoes.filter((t) => t.id !== id),
    }));
    addToast('Transação excluída.', 'info');
  };

  // --- ACCOUNTS & CARDS HANDLERS ---
  const handleSaveAccount = (account: Account) => {
    setData((prev) => {
      const exists = prev.contas.some((a) => a.id === account.id);
      return {
        ...prev,
        contas: exists
          ? prev.contas.map((a) => (a.id === account.id ? account : a))
          : [...prev.contas, account],
      };
    });
    addToast('Conta bancária salva com sucesso!');
  };

  const handleDeleteAccount = (id: string) => {
    setData((prev) => ({
      ...prev,
      contas: prev.contas.filter((a) => a.id !== id),
    }));
    addToast('Conta removida.', 'info');
  };

  const handleSaveCard = (card: CreditCard) => {
    setData((prev) => {
      const exists = prev.cartoes.some((c) => c.id === card.id);
      return {
        ...prev,
        cartoes: exists
          ? prev.cartoes.map((c) => (c.id === card.id ? card : c))
          : [...prev.cartoes, card],
      };
    });
    addToast('Cartão de crédito salvo com sucesso!');
  };

  const handleDeleteCard = (id: string) => {
    setData((prev) => ({
      ...prev,
      cartoes: prev.cartoes.filter((c) => c.id !== id),
    }));
    addToast('Cartão de crédito removido.', 'info');
  };

  // --- FINANCIAL GOALS HANDLERS ---
  const handleSaveGoal = (goal: FinancialGoal) => {
    setData((prev) => {
      const exists = prev.metas.some((g) => g.id === goal.id);
      return {
        ...prev,
        metas: exists
          ? prev.metas.map((g) => (g.id === goal.id ? goal : g))
          : [...prev.metas, goal],
      };
    });
    addToast('Meta financeira atualizada!');
  };

  const handleDeleteGoal = (id: string) => {
    setData((prev) => ({
      ...prev,
      metas: prev.metas.filter((g) => g.id !== id),
    }));
    addToast('Meta financeira excluída.', 'info');
  };

  const handleUpdateGoalBalance = (id: string, newBalance: number) => {
    setData((prev) => ({
      ...prev,
      metas: prev.metas.map((g) => (g.id === id ? { ...g, valorAtual: newBalance } : g)),
    }));
    addToast('Saldo da meta atualizado com sucesso!');
  };

  // --- TASKS HANDLERS ---
  const handleSaveTask = (taskData: Omit<Task, 'id' | 'criadaEm'>, editId?: string) => {
    if (editId) {
      setData((prev) => ({
        ...prev,
        tarefas: prev.tarefas.map((t) => (t.id === editId ? { ...t, ...taskData } : t)),
      }));
      addToast('Tarefa atualizada!');
    } else {
      const newTask: Task = {
        ...taskData,
        id: `task-${Date.now()}`,
        criadaEm: new Date().toISOString().slice(0, 10),
      };
      setData((prev) => ({
        ...prev,
        tarefas: [newTask, ...prev.tarefas],
      }));
      addToast('Nova tarefa criada!');
    }
  };

  const handleDeleteTask = (id: string) => {
    setData((prev) => ({
      ...prev,
      tarefas: prev.tarefas.filter((t) => t.id !== id),
    }));
    addToast('Tarefa excluída.', 'info');
  };

  const handleToggleTaskComplete = (id: string) => {
    setData((prev) => ({
      ...prev,
      tarefas: prev.tarefas.map((t) =>
        t.id === id
          ? {
              ...t,
              concluida: !t.concluida,
              status: (!t.concluida ? 'concluida' : 'a_fazer') as TaskStatus,
            }
          : t
      ),
    }));
  };

  const handleUpdateTaskStatus = (id: string, status: TaskStatus) => {
    setData((prev) => ({
      ...prev,
      tarefas: prev.tarefas.map((t) =>
        t.id === id
          ? {
              ...t,
              status,
              concluida: status === 'concluida',
            }
          : t
      ),
    }));
  };

  // --- HABITS HANDLERS ---
  const handleSaveHabit = (habitData: Omit<Habit, 'id' | 'criadoEm' | 'historicoDias'>, editId?: string) => {
    if (editId) {
      setData((prev) => ({
        ...prev,
        habitos: prev.habitos.map((h) => (h.id === editId ? { ...h, ...habitData } : h)),
      }));
      addToast('Hábito atualizado!');
    } else {
      const newHabit: Habit = {
        ...habitData,
        id: `hab-${Date.now()}`,
        historicoDias: [],
        criadoEm: new Date().toISOString().slice(0, 10),
      };
      setData((prev) => ({
        ...prev,
        habitos: [...prev.habitos, newHabit],
      }));
      addToast('Novo hábito registrado!');
    }
  };

  const handleDeleteHabit = (id: string) => {
    setData((prev) => ({
      ...prev,
      habitos: prev.habitos.filter((h) => h.id !== id),
    }));
    addToast('Hábito excluído.', 'info');
  };

  const handleToggleHabitDay = (habitId: string, dateStr: string) => {
    setData((prev) => ({
      ...prev,
      habitos: prev.habitos.map((h) => {
        if (h.id === habitId) {
          const exists = h.historicoDias.includes(dateStr);
          const newHist = exists
            ? h.historicoDias.filter((d) => d !== dateStr)
            : [...h.historicoDias, dateStr];
          return { ...h, historicoDias: newHist };
        }
        return h;
      }),
    }));
  };

  // --- NOTES HANDLERS ---
  const handleSaveNote = (noteData: Omit<NoteItem, 'id' | 'atualizadoEm'>, editId?: string) => {
    const nowIso = new Date().toISOString();
    if (editId) {
      setData((prev) => ({
        ...prev,
        notas: prev.notas.map((n) =>
          n.id === editId ? { ...noteData, id: editId, atualizadoEm: nowIso } : n
        ),
      }));
      addToast('Anotação atualizada!');
    } else {
      const newNote: NoteItem = {
        ...noteData,
        id: `note-${Date.now()}`,
        atualizadoEm: nowIso,
      };
      setData((prev) => ({
        ...prev,
        notas: [newNote, ...prev.notas],
      }));
      addToast('Nova nota criada!');
    }
  };

  const handleDeleteNote = (id: string) => {
    setData((prev) => ({
      ...prev,
      notas: prev.notas.filter((n) => n.id !== id),
    }));
    addToast('Nota excluída.', 'info');
  };

  const handleToggleNotePin = (id: string) => {
    setData((prev) => ({
      ...prev,
      notas: prev.notas.map((n) => (n.id === id ? { ...n, fixado: !n.fixado } : n)),
    }));
  };

  // --- OPEN FINANCE & AUTOMATIONS & SECURITY HANDLERS ---
  const handleSaveRule = (rule: AutomatedTransferRule) => {
    setData((prev) => {
      const exists = prev.regrasAutomacao.some((r) => r.id === rule.id);
      return {
        ...prev,
        regrasAutomacao: exists
          ? prev.regrasAutomacao.map((r) => (r.id === rule.id ? rule : r))
          : [rule, ...prev.regrasAutomacao],
      };
    });
    addToast('Regra de automação salva com sucesso!');
  };

  const handleDeleteRule = (id: string) => {
    setData((prev) => ({
      ...prev,
      regrasAutomacao: prev.regrasAutomacao.filter((r) => r.id !== id),
    }));
    addToast('Regra de automação excluída.', 'info');
  };

  const handleToggleRule = (id: string) => {
    setData((prev) => ({
      ...prev,
      regrasAutomacao: prev.regrasAutomacao.map((r) =>
        r.id === id ? { ...r, ativa: !r.ativa } : r
      ),
    }));
    addToast('Status da regra atualizado!');
  };

  const handleExecuteRuleNow = (rule: AutomatedTransferRule) => {
    const currentHour = new Date().getHours();
    const isNight = currentHour >= 20 || currentHour < 6;

    if (data.seguranca.modoSegurancaAtivo) {
      if (isNight && rule.valor > data.seguranca.limiteTransferenciaNoturno) {
        addToast(
          `Operação excede o limite noturno (R$ ${data.seguranca.limiteTransferenciaNoturno.toFixed(2)} entre 20h e 06h).`,
          'error'
        );
        return;
      }
      if (rule.valor > data.seguranca.limiteTransferenciaDiurno) {
        addToast(
          `Operação excede o limite diurno configurado (R$ ${data.seguranca.limiteTransferenciaDiurno.toFixed(2)}).`,
          'error'
        );
        return;
      }
    }

    const fromAcc =
      data.contas.find((a) => a.nome === rule.contaOrigemNome || a.instituicao === rule.contaOrigemNome) ||
      data.contas[0];
    const toAcc =
      data.contas.find((a) => a.nome === rule.contaDestinoNome || a.instituicao === rule.contaDestinoNome) ||
      data.contas[1] ||
      data.contas[0];

    const todayDate = new Date().toISOString().slice(0, 10);
    const timeStr = new Date().toLocaleTimeString('pt-BR');
    const randEndToEnd = `E00416968${todayDate.replace(/-/g, '')}${Math.floor(1000000000 + Math.random() * 9000000000)}`;
    const bacenProto = `BACEN-PIX-ITP-${Date.now().toString().slice(-6)}-${Math.floor(1000 + Math.random() * 9000)}`;
    const hashSha = Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('');

    const newTx: Transaction = {
      id: `tx-openfinance-${Date.now()}`,
      tipo: 'transferencia',
      valor: rule.valor,
      categoria: 'Transferência Open Finance',
      data: todayDate,
      descricao: `Automação Pix Open Finance: ${rule.titulo}`,
      contaId: fromAcc.id,
      contaDestinoId: toAcc.id,
      protocoloOpenFinance: bacenProto,
      tags: ['open-finance', 'automacao', 'pix', 'itp'],
      status: 'pago',
      observacoes: `Execução autorizada via certificado digital mTLS e protocolo Bacen nº ${rule.protocoloBacenConsent}`,
    };

    const nextExec = calculateNextExecution(rule.frequencia, todayDate);
    const updatedRules = data.regrasAutomacao.map((r) =>
      r.id === rule.id ? { ...r, ultimaExecucao: todayDate, proximaExecucao: nextExec } : r
    );

    setData((prev) => ({
      ...prev,
      transacoes: [newTx, ...prev.transacoes],
      regrasAutomacao: updatedRules,
    }));

    setReceiptData({
      id: newTx.id,
      endToEndId: randEndToEnd,
      protocoloBacen: bacenProto,
      timestamp: `${formatDateBR(todayDate)} às ${timeStr}`,
      valor: rule.valor,
      contaOrigemNome: fromAcc.nome,
      bancoOrigem: fromAcc.instituicao,
      contaDestinoNome: toAcc.nome,
      bancoDestino: toAcc.instituicao,
      chavePixDestino: rule.chavePixDestino,
      hashAutenticacao: hashSha,
      regraTitulo: rule.titulo,
    });

    addToast('Transferência bancária automatizada liquidada com sucesso no SPI!', 'success');
  };

  const handleSavePortability = (req: PortabilityRequest) => {
    setData((prev) => {
      const exists = prev.portabilidades.some((p) => p.id === req.id);
      return {
        ...prev,
        portabilidades: exists
          ? prev.portabilidades.map((p) => (p.id === req.id ? req : p))
          : [req, ...prev.portabilidades],
      };
    });
    addToast('Solicitação de portabilidade registrada!', 'success');
  };

  const handleDeletePortability = (id: string) => {
    setData((prev) => ({
      ...prev,
      portabilidades: prev.portabilidades.filter((p) => p.id !== id),
    }));
    addToast('Portabilidade removida do histórico.', 'info');
  };

  const handleConnectBankConsent = (consent: OpenFinanceConsent) => {
    setData((prev) => ({
      ...prev,
      consents: [consent, ...prev.consents.filter((c) => c.codigoBanco !== consent.codigoBanco)],
    }));
    addToast(`Banco ${consent.instituicao} conectado ao Open Finance!`, 'success');
  };

  const handleRevokeConsent = (id: string) => {
    setData((prev) => ({
      ...prev,
      consents: prev.consents.map((c) => (c.id === id ? { ...c, status: 'revogado' as const } : c)),
    }));
    addToast('Consentimento Open Finance revogado.', 'info');
  };

  const handleSaveSecurityConfig = (cfg: SecurityConfig) => {
    setData((prev) => ({
      ...prev,
      seguranca: cfg,
    }));
    addToast('Parâmetros de segurança atualizados!', 'success');
  };

  const handleEmergencyFreeze = () => {
    setData((prev) => ({
      ...prev,
      seguranca: {
        ...prev.seguranca,
        modoSegurancaAtivo: true,
      },
      regrasAutomacao: prev.regrasAutomacao.map((r) => ({ ...r, ativa: false })),
    }));
    addToast('Bloqueio de Emergência ativado! Todas as transferências automáticas foram pausadas.', 'error');
  };

  const handleTogglePrivacyMask = () => {
    setData((prev) => ({
      ...prev,
      seguranca: {
        ...prev.seguranca,
        ocultarValores: !prev.seguranca.ocultarValores,
      },
    }));
    addToast(
      !data.seguranca.ocultarValores ? 'Modo Privacidade ativado: valores monetários ocultados.' : 'Valores visíveis na tela.',
      'info'
    );
  };

  // --- BACKUP & SYSTEM ACTIONS ---
  const handleImportData = (importedData: AppData) => {
    setData(importedData);
    addToast('Base de dados restaurada com sucesso!');
  };

  const handleResetToDefault = () => {
    setData(INITIAL_DATA);
    addToast('Dados restaurados para o padrão de demonstração!');
  };

  const handleClearAll = () => {
    setData({
      contas: [
        {
          id: 'acc-1',
          nome: 'Conta Principal',
          tipo: 'corrente',
          saldoInicial: 0,
          instituicao: 'Banco',
          cor: '#8B5CF6',
        },
      ],
      cartoes: [],
      transacoes: [],
      metas: [],
      tarefas: [],
      habitos: [],
      notas: [],
      consents: [],
      portabilidades: [],
      regrasAutomacao: [],
      seguranca: INITIAL_SECURITY,
    });
    addToast('Todos os registros foram apagados.', 'info');
  };

  return (
    <div className="min-h-screen flex flex-col bg-neutral-50 dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 transition-colors">
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={(tab) => {
          setActiveTab(tab);
          if (tab === 'finance') {
            setFinanceSubTab('charts');
          }
        }}
        onOpenQuickAction={() => setIsQuickActionOpen(true)}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenSupabase={() => setIsSupabaseModalOpen(true)}
        onOpenSecurity={() => setIsSecurityModalOpen(true)}
        isSecurityModeActive={data.seguranca.modoSegurancaAtivo}
        isValuesMasked={data.seguranca.ocultarValores}
        onTogglePrivacyMask={handleTogglePrivacyMask}
        isDarkMode={isDarkMode}
        setIsDarkMode={setIsDarkMode}
      />

      {/* Main Viewport Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 md:px-8 py-6 pb-24 md:pb-12">
        {activeTab === 'overview' && (
          <OverviewDashboard
            data={data}
            setActiveTab={(tab) => {
              setActiveTab(tab);
              if (tab === 'finance') {
                setFinanceSubTab('charts');
              }
            }}
            onNavigateToOpenFinance={() => {
              setActiveTab('finance');
              setFinanceSubTab('openfinance');
            }}
            onToggleTask={handleToggleTaskComplete}
            onToggleHabitDay={handleToggleHabitDay}
            onOpenQuickAction={() => setIsQuickActionOpen(true)}
            onOpenNewTransaction={() => {
              setEditingTx(null);
              setIsTxModalOpen(true);
            }}
            onOpenNewTask={() => {
              setEditingTask(null);
              setIsTaskModalOpen(true);
            }}
            onOpenNewGoal={() => {
              setEditingGoal(null);
              setIsGoalModalOpen(true);
            }}
          />
        )}

        {activeTab === 'finance' && (
          <FinanceModule
            transactions={data.transacoes}
            accounts={data.contas}
            cards={data.cartoes}
            goals={data.metas}
            consents={data.consents}
            portabilidades={data.portabilidades}
            regras={data.regrasAutomacao}
            securityConfig={data.seguranca}
            initialSubTab={financeSubTab}
            onOpenNewTransaction={() => {
              setEditingTx(null);
              setIsTxModalOpen(true);
            }}
            onEditTransaction={(tx) => {
              setEditingTx(tx);
              setIsTxModalOpen(true);
            }}
            onDeleteTransaction={handleDeleteTransaction}
            onSaveAccount={handleSaveAccount}
            onDeleteAccount={handleDeleteAccount}
            onSaveCard={handleSaveCard}
            onDeleteCard={handleDeleteCard}
            onSaveGoal={handleSaveGoal}
            onDeleteGoal={handleDeleteGoal}
            onUpdateGoalBalance={handleUpdateGoalBalance}
            onSaveRule={handleSaveRule}
            onDeleteRule={handleDeleteRule}
            onToggleRule={handleToggleRule}
            onExecuteRuleNow={handleExecuteRuleNow}
            onSavePortability={handleSavePortability}
            onDeletePortability={handleDeletePortability}
            onConnectBankConsent={handleConnectBankConsent}
            onRevokeConsent={handleRevokeConsent}
            onOpenSecurityModal={() => setIsSecurityModalOpen(true)}
            onTogglePrivacyMask={handleTogglePrivacyMask}
            onShowToast={addToast}
          />
        )}

        {activeTab === 'tasks' && (
          <TaskManager
            tasks={data.tarefas}
            onOpenNewTask={() => {
              setEditingTask(null);
              setIsTaskModalOpen(true);
            }}
            onEditTask={(task) => {
              setEditingTask(task);
              setIsTaskModalOpen(true);
            }}
            onDeleteTask={handleDeleteTask}
            onToggleComplete={handleToggleTaskComplete}
            onUpdateStatus={handleUpdateTaskStatus}
          />
        )}

        {activeTab === 'habits' && (
          <HabitsTracker
            habits={data.habitos}
            onOpenNewHabit={() => {
              setEditingHabit(null);
              setIsHabitModalOpen(true);
            }}
            onEditHabit={(habit) => {
              setEditingHabit(habit);
              setIsHabitModalOpen(true);
            }}
            onDeleteHabit={handleDeleteHabit}
            onToggleDay={handleToggleHabitDay}
          />
        )}

        {activeTab === 'notes' && (
          <NotesAgenda
            notes={data.notas}
            onOpenNewNote={() => {
              setEditingNote(null);
              setIsNoteModalOpen(true);
            }}
            onEditNote={(note) => {
              setEditingNote(note);
              setIsNoteModalOpen(true);
            }}
            onDeleteNote={handleDeleteNote}
            onTogglePin={handleToggleNotePin}
          />
        )}
      </main>

      {/* Mobile Bottom Navigation */}
      <BottomNav
        activeTab={activeTab}
        setActiveTab={(tab) => {
          setActiveTab(tab);
          if (tab === 'finance') {
            setFinanceSubTab('charts');
          }
        }}
      />

      {/* Floating Toast Feedback Notifications */}
      <ToastContainer toasts={toasts} onDismiss={removeToast} />

      {/* Quick Action Selector Modal */}
      <QuickActionModal
        isOpen={isQuickActionOpen}
        onClose={() => setIsQuickActionOpen(false)}
        onSelectAction={handleQuickActionSelect}
      />

      {/* Data Backup & Settings Modal */}
      <DataSettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        data={data}
        onImportData={handleImportData}
        onResetToDefault={handleResetToDefault}
        onClearAll={handleClearAll}
        onOpenSupabase={() => setIsSupabaseModalOpen(true)}
      />

      {/* Supabase Integration & SQL Modal */}
      <SupabaseModal
        isOpen={isSupabaseModalOpen}
        onClose={() => setIsSupabaseModalOpen(false)}
        onShowToast={addToast}
      />

      {/* Security & Vault Settings Modal */}
      <SecuritySettingsModal
        isOpen={isSecurityModalOpen}
        onClose={() => setIsSecurityModalOpen(false)}
        config={data.seguranca}
        onSaveConfig={handleSaveSecurityConfig}
        onEmergencyFreeze={handleEmergencyFreeze}
        onShowToast={addToast}
      />

      {/* Official Open Finance Transfer Receipt Modal */}
      <TransferReceiptModal
        receipt={receiptData}
        onClose={() => setReceiptData(null)}
      />

      {/* Creation / Edit Modals */}
      <TransactionModal
        isOpen={isTxModalOpen}
        onClose={() => setIsTxModalOpen(false)}
        onSave={handleSaveTransaction}
        accounts={data.contas}
        cards={data.cartoes}
        initialData={editingTx}
      />

      <TaskModal
        isOpen={isTaskModalOpen}
        onClose={() => setIsTaskModalOpen(false)}
        onSave={handleSaveTask}
        initialData={editingTask}
      />

      <HabitModal
        isOpen={isHabitModalOpen}
        onClose={() => setIsHabitModalOpen(false)}
        onSave={handleSaveHabit}
        initialData={editingHabit}
      />

      <GoalModal
        isOpen={isGoalModalOpen}
        onClose={() => setIsGoalModalOpen(false)}
        onSave={handleSaveGoal}
        initialData={editingGoal}
      />

      <NoteModal
        isOpen={isNoteModalOpen}
        onClose={() => setIsNoteModalOpen(false)}
        onSave={handleSaveNote}
        initialData={editingNote}
      />
    </div>
  );
}
